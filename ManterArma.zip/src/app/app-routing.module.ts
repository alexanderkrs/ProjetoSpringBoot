import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ArmaRoutes } from './arma/arma.routing';

const routes: Routes = [
  ...ArmaRoutes
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
