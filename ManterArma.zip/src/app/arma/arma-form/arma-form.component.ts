import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Arma } from '../shared/arma';
import { ArmaService } from '../shared/arma.service';

@Component({
  selector: 'app-arma-form',
  templateUrl: './arma-form.component.html',
  styleUrls: ['./arma-form.component.css']
})
export class ArmaFormComponent implements OnInit {
  arma: Arma = new Arma();

  constructor(private armaService: ArmaService,
    private route: ActivatedRoute,
    private router: Router) { }

  ngOnInit(): void {
    const id = this.route.snapshot.paramMap.get('id');
    if(id){
      this.armaService.getByID(parseInt(id)).subscribe((arma)=> {
        this.arma = arma;
      }, erro => {
        alert("Erro ao buscar a Arma com id:"+id);
      });
    }
  }

  public salvar(arma: Arma){
    let acao="criada";
    if(arma.id){
      acao = "alterada";
    }
    this.armaService.salvar(arma).subscribe((arma)=> {
      alert("Arma "+acao+" com Sucesso!");
      this.router.navigate(['arma'])
    }, erro => {
      alert(erro); 
    })
  }

}
