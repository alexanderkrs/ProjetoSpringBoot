import { Component, OnInit } from '@angular/core';
import { Arma } from '../shared/arma';
import { ArmaService } from '../shared/arma.service';

@Component({
  selector: 'app-arma-list',
  templateUrl: './arma-list.component.html',
  styleUrls: ['./arma-list.component.css']
})
export class ArmaListComponent implements OnInit {
  armas: Arma[] = [];

  constructor(private armaService: ArmaService) { }

  ngOnInit(): void {
    this.armaService.getArmas().subscribe((armas:Arma[]) =>{
      console.log("Arma",armas);
      this.armas = armas;
    });
  }
  confirmaRemocao(arma: Arma){
    let mensagem = "Deseja remover a arma: \n Marca:"+arma.marca+", Modelo:"+arma.modelo+", Calibre:"+arma.calibre;
    if(confirm(mensagem)){
      this.armaService.remover(arma.id).subscribe((arma) =>{
        let armaIdx = this.armas.findIndex( (value) => value.id == arma.id);
        this.armas.splice(armaIdx, 1);
        alert("Arma removida com sucesso!");
      }, erro => {
        alert("Erro ao excluir arma. Mensagem: "+erro?.error?.message);
      });
    }
  }

}
