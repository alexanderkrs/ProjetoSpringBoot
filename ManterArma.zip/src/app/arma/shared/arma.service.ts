import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
import { Arma } from './arma';
 
@Injectable({
  providedIn: 'root'
})
export class ArmaService {
  urlBackend: string = "http://localhost:8081" 

  constructor(private http: HttpClient) { }

  public getArmas(): Observable<Arma[]> {
    return this.http.get<Arma[]>(this.urlBackend+"/armas");
  }
  public salvar(arma: Arma): Observable<Arma> {
    if(!arma.id){
      return this.http.post<Arma>(this.urlBackend+"/armas",arma);
    } else {
      return this.http.patch<Arma>(this.urlBackend+"/armas/update/"+arma.id,arma);
    }
    
  }
  public getByID(id: number): Observable<Arma> {
    return this.http.get<Arma>(this.urlBackend+"/armas/"+id);
  }

  public remover(id: number): Observable<Arma> {
    return this.http.delete<Arma>(this.urlBackend+"/armas/"+id);
  }
}
