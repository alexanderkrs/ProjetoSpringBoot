export class Arma {
    id!: number;
	marca!: string;
	modelo!: string;
	calibre!: number;
}
