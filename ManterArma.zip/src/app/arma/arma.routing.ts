import { Routes } from "@angular/router";
import { ArmaFormComponent } from "./arma-form/arma-form.component";
import { ArmaListComponent } from "./arma-list/arma-list.component";
import { ArmaComponent } from "./arma.component";

export const ArmaRoutes: Routes = [
    {
        path: "arma",
        component: ArmaComponent,
        children: [
            {
                path: "",
                component: ArmaListComponent 
            },
            {
                path: "novo",
                component: ArmaFormComponent
            },
            {
                path:"editar/:id",
                component: ArmaFormComponent
            }
        ]
    },
];