import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ArmaComponent } from './arma.component';
import { ArmaFormComponent } from './arma-form/arma-form.component';
import { ArmaListComponent } from './arma-list/arma-list.component';
import { RouterModule } from '@angular/router';
import { ArmaRoutes } from './arma.routing';
import { FormsModule } from '@angular/forms';




@NgModule({
  declarations: [
    ArmaComponent,
    ArmaFormComponent,
    ArmaListComponent
  ],
  imports: [
    FormsModule,
    CommonModule,
    RouterModule.forChild(ArmaRoutes)
  ]
})
export class ArmaModule { }
